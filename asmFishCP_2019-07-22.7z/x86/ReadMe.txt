version for x86-64 processors
